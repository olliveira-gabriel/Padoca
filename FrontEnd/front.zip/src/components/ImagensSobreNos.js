import React from 'react'

function ImagensSobreNos(props) {
  return (
    <div>
        <img src={props.ImgSobreNos} />
    </div>
  )
}

export default ImagensSobreNos